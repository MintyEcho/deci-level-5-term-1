# Shop

A full-stack e-commerce app: React frontend, Express backend, PostgreSQL (via Prisma), and MongoDB.

## Tech stack

- Frontend: React, Vite, React Router, React Query, Axios, Tailwind CSS
- Backend: Node.js, Express
- Databases: PostgreSQL (Prisma ORM), MongoDB (Mongoose)
- Auth: JWT, bcrypt
- Testing: Jest, Supertest, React Testing Library, MSW
- Other: Nodemailer (welcome email), Multer (image upload), Docker Compose

## Project structure

```
backend/
  prisma/          schema, migrations, seed script
  src/
    config/        Prisma and MongoDB connections
    controllers/    route handlers
    routes/         API routes
    middlewares/    auth, RBAC, upload
    services/       email, activity log
    models/         MongoDB models
    tests/          Jest unit + Supertest integration tests
    app.js          Express app (exported for tests)
    index.js        server entry point
frontend/
  src/
    pages/          Home, Products, ProductDetails, Cart, Admin, Login, Register, Profile
    components/     NavBar, ProductCard, Loading, ErrorMessage, ProtectedRoute
    context/         AuthContext
    tests/           Vitest + React Testing Library + MSW
```

## Setup

1. Install PostgreSQL and MongoDB, or run them with Docker:
   ```
   docker compose up -d
   ```

2. Backend:
   ```
   cd backend
   cp .env.example .env
   npm install
   npx prisma migrate dev --name init
   npm run seed
   npm run dev
   ```
   Runs on http://localhost:5000

3. Frontend:
   ```
   cd frontend
   cp .env.example .env
   npm install
   npm run dev
   ```
   Runs on http://localhost:3000

## Environment variables

**backend/.env**
- `DATABASE_URL` — PostgreSQL connection string
- `MONGO_URI` — MongoDB connection string
- `JWT_SECRET` — secret used to sign auth tokens
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` — optional, for welcome emails. If left empty, the app logs the email instead of sending it.

**frontend/.env**
- `VITE_API_URL` — base URL of the backend API (default: `http://localhost:5000/api`)

## Testing

Backend:
```
cd backend
npm test
```

Frontend:
```
cd frontend
npm test
```

## Seed data

`npm run seed` (from `backend/`) creates an admin user, a customer user, sample categories, and sample products so the app has data to test against right away.

## Notes

- Product images are uploaded via `multer` and stored under `backend/uploads`, referenced by URL in the database.
- Reviews and activity logs are stored in MongoDB; everything else is in PostgreSQL.
- The Prisma client is generated with the binary engine (not wasm) for compatibility with newer Node versions.
